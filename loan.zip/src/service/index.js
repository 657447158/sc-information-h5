import common from './common'

const api = Object.assign({...common})

export default api